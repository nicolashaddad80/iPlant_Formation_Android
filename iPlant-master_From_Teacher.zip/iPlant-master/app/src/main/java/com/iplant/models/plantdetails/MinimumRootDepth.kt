package com.iplant.models.plantdetails


import com.squareup.moshi.Json

data class MinimumRootDepth(
    @field:Json(name = "cm")
    val cm: Any?
)